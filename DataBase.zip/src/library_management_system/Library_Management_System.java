
package library_management_system;

public class Library_Management_System {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
